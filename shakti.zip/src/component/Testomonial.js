const testimonialsData = [
    {
      name: "Sr Janen Sara",
      job: "Sr. Web Developer",
      feedback:
        "Proin libero vel lorem dui. Lorem est aliquet luctus purus justo eget libero sed lorem.",
      imageUrl: "path_to_image_1.jpg",
    },
    {
      name: "Afsana Nila",
      job: "App Developer",
      feedback:
        "Wow, but really wow... The template is nice, but it had some challenges.",
      imageUrl: "path_to_image_2.jpg",
    },
    {
      name: "Afanan Sifa",
      job: "Accounts Manager",
      feedback:
        "Proin libero vel lorem dui. Lorem est aliquet luctus purus justo eget libero sed lorem.",
      imageUrl: "path_to_image_3.jpg",
    },
  ];
  